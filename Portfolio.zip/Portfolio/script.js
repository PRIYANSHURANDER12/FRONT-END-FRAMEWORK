document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.querySelector('.login'); // Select the form by class name
    const usernameInput = document.querySelector('input[type="text"]'); // Select the username input
    const passwordInput = document.querySelector('input[type="password"]'); // Select the password input

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const username = usernameInput.value;
        const password = passwordInput.value;

        // Replace with your authentication logic
        if (username === 'Priyanshu' && password === 'Champion@1234') {
            // Redirect to the next page
            window.location.href = 'index.html';
        } else {
            alert('Invalid username or password');
        }
    });
});
