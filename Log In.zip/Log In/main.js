document.addEventListener("DOMContentLoaded", function () {
    const loginButton = document.getElementById("loginButton");
    const signupButton = document.getElementById("signupButton");
    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");

    // Show login form by default
    loginForm.style.display = "block";
    signupForm.style.display = "none";

    loginButton.addEventListener("click", function () {
        loginForm.style.display = "block";
        signupForm.style.display = "none";
        loginButton.classList.add("active");
        signupButton.classList.remove("active");
    });

    signupButton.addEventListener("click", function () {
        loginForm.style.display = "none";
        signupForm.style.display = "block";
        signupButton.classList.add("active");
        loginButton.classList.remove("active");
    });
});


function validateForm() {
    // Validation code for the registration form
    const username = document.getElementById('username').value;
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    // Regular expressions for validation
    const usernameRegex = /^[a-zA-Z0-9_]+$/;
    const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*])(.{8,10})$/;
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    const phoneNumberRegex = /^[0-9]{10}$/;

    // Reset error messages
    document.getElementById('usernameError').textContent = '';
    document.getElementById('firstNameError').textContent = '';
    document.getElementById('lastNameError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('phoneNumberError').textContent = '';
    document.getElementById('passwordError').textContent = '';
    document.getElementById('confirmPasswordError').textContent = '';

    let isValid = true;

    if (!username.match(usernameRegex)) {
        document.getElementById('usernameError').textContent = 'Username should contain only letters, numbers, and underscores.';
        isValid = false;
    }

    if (!password.match(passwordRegex)) {
        document.getElementById('passwordError').textContent = 'Password should contain at least 1 uppercase letter, 1 special character, and be 8-10 characters long.';
        isValid = false;
    }

    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match.';
        isValid = false;
    }

    if (!firstName) {
        document.getElementById('firstNameError').textContent = 'First Name cannot be blank.';
        isValid = false;
    }

    if (!lastName) {
        document.getElementById('lastNameError').textContent = 'Last Name cannot be blank.';
        isValid = false;
    }

    if (!email.match(emailRegex)) {
        document.getElementById('emailError').textContent = 'Invalid email format.';
        isValid = false;
    }

    if (!phoneNumber.match(phoneNumberRegex)) {
        document.getElementById('phoneNumberError').textContent = 'Phone Number should be 10 digits long and contain only numbers.';
        isValid = false;
    }

    if (isValid) {
        alert('Registration Successful');
    } else {
        alert('Invalid Input');
    }
}

function validateLogin() {
    // Validation code for the login form
    const loginUsername = document.getElementById('loginUsername').value;
    const loginPassword = document.getElementById('loginPassword').value;

    // Check if fields are blank
    if (!loginUsername || !loginPassword) {
        alert('Username and Password are required fields.');
    } else {
        alert('Login Successful');
    }
}
